
import AllRoutes from './routing'
function App() {

  return (
    <>
      <AllRoutes/>
    </>
  )
}
export default App

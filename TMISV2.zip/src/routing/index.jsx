import PrivateRoutes from "./private/private.jsx"
import { BrowserRouter,Routes,Route } from "react-router-dom"
const AllRoutes = () => {
    return (
        <Routes>
            <Route path="/private/*" element={<PrivateRoutes />} />
        </Routes>
    )
}
export default AllRoutes 
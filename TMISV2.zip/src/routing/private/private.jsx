import PrivateFeatures from "./features"
import { BrowserRouter,Route, Routes } from "react-router"

const PrivateRoutes = () => {
    return (
        <Routes>
            <Route path="/features/*" element={<PrivateFeatures />} />
        </Routes>
    )
}

export default PrivateRoutes
import React from "react";
import { Route, Routes, Navigate } from "react-router-dom";
import { Component } from "../../../ui/sidebar/sidebar";
import Bprdadmin from "../../../features/bprddetails/bprdadmin";
import Cdtiadmin from "../../../features/cdtiadmin/cdtiadmin";
import { Managerank } from "../../../features/managerank/rankpage/managerank";
import Manageorg from "../../../features/manageorganisation/manageorg/existingpage";
import { Assignrole } from "../../../features/assignrole/assignrole";
import { Manageuser } from "../../../features/manageuser/user/manageuser";
import { Addorganization } from "../../../features/manageorganisation/manageorg/addorganization";
import Editorganization from "../../../features/manageorganisation/manageorg/editorganization";
import { AddRank } from "../../../features/managerank/rankpage/addrank";
import { EditRank } from "../../../features/managerank/rankpage/editrank";
import { Adduser } from "../../../features/manageuser/user/adduser";
import Navbar from "../../../ui/navbar/navbar";
import { Footer } from "../../../ui/footer/footer";
const PrivateFeatures = () => {
  return (
    <div className="h-screen overflow-hidden flex flex-col gap-3 w-full w-screen">
      <Navbar />
      <div className="flex-1 overflow-hidden">
        <div className="flex flex-row gap-3 h-full">
          <div className="basis-2/12 h-full w-full">
            <Component />
          </div>
          <div className="basis-10/12 h-full w-full overflow-auto ">
            <Routes>
              <Route path="/" element={<Navigate to="dashboard" />} />
              <Route path="/dashboard" element={<h2>Dashboard</h2>} />
              <Route path="/bprd-admin-details" element={<Bprdadmin />} />
              <Route path="/cdti-admin-details" element={<Cdtiadmin />} />
              <Route path="/manage-rank" element={<Managerank />} />
              <Route path="/manage-organization" element={<Manageorg />} />
              <Route path="/assign-role" element={<Assignrole />} />
              <Route path="/manage-user" element={<Manageuser />} />
              <Route path="/manage-organization/*">
                <Route path="add-organization" element={<Addorganization />} />
                <Route path="edit-organization" element={<Editorganization />} />
              </Route>
              <Route path="/manage-rank/*">
                <Route path="add-rank" element={<AddRank />} />
                <Route path="edit-rank" element={<EditRank />} />
              </Route>
              <Route path="/manage-user/*">
                <Route path="add-user" element={<Adduser />} />
              </Route>
            </Routes>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  )
};
export default PrivateFeatures;


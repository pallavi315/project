
import React from "react";

export function Footer() {
  return (
    <footer className="flex justify-center bg-gray-100  bottom-7 left-0 w-full  p-4">
      <div className="w-full w-full">
        <span className="block text-sm ">
          © 2024{" "}
          <a
            href="https://cdac.in/"
            className="hover:underline text-black"
          >
            Design and Developed by C-DAC, Hyderabad
          </a>
        </span>
      </div>
    </footer>
  );
}


import React from "react";
import {  useNavigate } from "react-router-dom";
export function Form({title}){
  const navigate=useNavigate()
  return (
    <div className="p-6 bg-white rounded-lg mx-auto w-full">
      
      <form>
        <label className="block mb-4">
          <span className="text-gray-700 font-bold">Organization Name *</span>
          <input
            type="text"
            placeholder="Enter Organization Name"
            className="block w-full border border-gray-300 rounded-lg p-2 mt-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
          />
        </label>
        <label className="block mb-4">
          <span className="text-gray-700 font-bold">Organization Address *</span>
          <input
            type="text"
            placeholder="Enter Organization Address"
            className="block w-full border border-gray-300 rounded-lg p-2 mt-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
          />
        </label>
    
        <label className="block mb-4">
          <span className="text-gray-700 font-bold">Organization Code *</span>
          <input
            type="text"
            placeholder="Enter Organization Code"
            className="block w-full border border-gray-300 rounded-lg p-2 mt-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"/>
        </label>
        
        <button
          type="submit"
          className="bg-blue-500 text-white text-center py-2 rounded-lg hover:bg-blue-600 transition-colors"
          onClick={() => navigate("/private/features/manage-organization")}>
          Submit
        </button>
      </form>
    </div>
  );
}


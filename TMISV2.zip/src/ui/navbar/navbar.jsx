
import React, { useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCircleUser } from "@fortawesome/free-solid-svg-icons";
const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };
  return (
    <nav className="bg-gray-100 py-3  w-full ">
  <div className=" mx-auto flex justify-between pl-3">
    {/* Logo/Brand */}
    <div className="text-lg font-semibold flex ">
      <a href="/" className="hover:text-gray-200 ">
        <img
          src="https://tmis.bprd.nic.in/bprd-logo-text.png"
          className="h-12"
          alt="Logo"
        />
      </a>
    </div>
    {/* Welcome Text */}
    <div className="flex items-center pr-3">
      <div className="rounded-full p-2 flex items-center">
        <FontAwesomeIcon icon={faCircleUser} size="2x" />
      </div>
      <span className="font-semibold text-sm md:text-base">
        Welcome BPRD Super Admin
      </span>
    </div>
  </div>
</nav>
  );
};
export default Navbar;

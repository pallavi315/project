const BackgroundCard = ({ children, className, disableHeight = false, disableHeightForSM = false, background }) => {
    return (
        <div className={`w-full ${disableHeightForSM ? `${!disableHeight && 'sm:h-full'}` : `${!disableHeight && 'h-full'}`} p-3 ${background !== null && 'bg-gray-50 dark:bg-gray-750'} border border-gray-200 dark:border-gray-700 rounded-xl dark:text-white ${className}`}>
            {children}
        </div>
    )
}

export default BackgroundCard
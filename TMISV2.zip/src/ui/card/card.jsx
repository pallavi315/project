const Card = ({ children, className, disableHeight = false, disableHeightForSM = false }) => {
    return (
        <div className={`w-full ${disableHeightForSM ? `${!disableHeight && 'sm:h-full'}` : `${!disableHeight && 'h-full'}`} bg-white border border-gray-200 rounded-xl p-3 dark:bg-gray-800 dark:border-gray-700 dark:text-white ${className}`}>
            {children}
        </div>
    )
}

export default Card

import React from "react";
import { Sidebar } from "flowbite-react";
import { HiUser, HiHome,HiAcademicCap } from "react-icons/hi";
import { HiOfficeBuilding } from "react-icons/hi";
import { HiUserCircle } from "react-icons/hi";
import { HiUsers } from "react-icons/hi";
import { Link } from "react-router-dom";

export const Component = () => {
  return (
    
    <div className="h-full w-full flex pl-3">
      <div className="rounded-xl overflow-hidden border  bg-white w-full">
        <Sidebar aria-label="Sidebar with Tailwind CSS">
          <Sidebar.Items>
            <Sidebar.ItemGroup>
              <Link to="/private/features/Dashboard">
                <Sidebar.Item
                  href="#"
                  icon={HiHome}
                  className="text-gray-700 hover:text-blue-500 items-center space-x-3"
                >
                  Dashboard
                </Sidebar.Item>
              </Link>
              <Link to="/private/features/manage-organization">
                <Sidebar.Item
                  href="#"
                  icon={HiOfficeBuilding}
                  className="text-gray-700 hover:text-blue-500 items-center space-x-3 "
                >
                  Manage Organization
                </Sidebar.Item>
              </Link>
              <Link to="/private/features/manage-rank">
                <Sidebar.Item
                  href="#"
                  icon={HiAcademicCap}
                  className="text-gray-700 hover:text-blue-500 items-center space-x-3 "
                >
                  Manage Rank
                </Sidebar.Item>
              </Link>
              <Link to="/private/features/manage-user">
                <Sidebar.Item
                  href="#"
                  icon={HiUser}
                  className="text-gray-700 hover:text-blue-500 items-center space-x-3 "
                >
                  Manage User
                </Sidebar.Item>
              </Link>
              <Link to="/private/features/assign-role">
                <Sidebar.Item
                  href="#"
                  icon={HiUserCircle}
                  className="text-gray-700 hover:text-blue-500 items-center space-x-3 "
                >
                  Assign Role
                </Sidebar.Item>
              </Link>
              <Link to="/private/features/cdti-admin-details">
                <Sidebar.Item
                  href="#"
                  icon={HiUsers}
                  className="text-gray-700 hover:text-blue-500 items-center space-x-3"
                >
                  View CDTI Admin Details
                </Sidebar.Item>
              </Link>
              <Link to="/private/features/bprd-admin-details">
                <Sidebar.Item
                  href="#"
                  icon={HiUsers}
                  className="text-gray-700 hover:text-blue-500 items-center space-x-3"
                >
                  View BPR&D Admin Details
                </Sidebar.Item>
              </Link>
            </Sidebar.ItemGroup>
          </Sidebar.Items>
        </Sidebar>
      </div>
    </div>
  );
};

  
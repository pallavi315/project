const BasicTable = ({ data, headers, title, className }) => {
    return (
      <div className={`w-full h-full  bg-white  rounded-lg ${className}`}>
        
        <div className="overflow-x-auto">
          <table className="w-full table-auto text-left bg-gray-50  rounded-lg">
            <thead>
              {headers && (
                <tr>
                  {headers.map((header, index) => (
                    <th
                      key={index}
                      className="px-5 py-4 text-sm font-semibold border-b bg-gray-100 text-black">
                      {header}
                    </th>
                  ))}
                </tr>
              )}
            </thead>
            <tbody>
              {data.map((row, rowIndex) => (
                <tr key={rowIndex} className="hover:bg-gray-100">
                  {Object.values(row).map((cell, cellIndex) => (
                    <td
                      key={cellIndex}
                      className="px-5 py-4 text-sm border-b border-gray-200 text-black text-left">
                      {cell}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  };
  
  export default BasicTable;
  
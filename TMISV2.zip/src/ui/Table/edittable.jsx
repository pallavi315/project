
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faUserPen } from "@fortawesome/free-solid-svg-icons";
const EditTable = ({ data, headers, className, onEditclick }) => {
  return (
    <div className={`h-full bg-white ${className}`}>
      <div className="rounded ">
        <table className="w-full text-left bg-gray-50">
          <thead className="bg-gray-100">
            {headers && (
              <tr>
                {headers.map((header, index) => (
                  <th
                    key={index}
                    className="px-5 py-4 text-sm font-semibold border-b text-black"
                    style={{
                      position: "sticky",
                      top: 0,
                      zIndex: 10,
                      backgroundColor: "#f3f4f6", 
                    }}
                  >
                    {header}
                  </th>
                ))}
              </tr>
            )}
          </thead>
          <tbody>
            {data.map((row, rowIndex) => (
              <tr key={rowIndex} className="hover:bg-gray-100">
                {Object.entries(row).map(([key, value], cellIndex) => (
                  <td
                    key={cellIndex}
                    className="px-3 py-3 text-sm border-b border-gray-200 text-black text-left"
                  >
                    {value}
                  </td>
                ))}
                <td className="px-2 py-3 text-sm border-b border-gray-200 text-black">
                  <button
                    className="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 transition"
                    onClick={() => onEditclick(row)}
                  >
                    Edit <FontAwesomeIcon icon={faUserPen} className="pl-2" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
export default EditTable;

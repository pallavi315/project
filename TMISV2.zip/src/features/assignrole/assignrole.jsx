
import React, { useState, useEffect } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faUserXmark } from "@fortawesome/free-solid-svg-icons";
export function Assignrole() {
  const [institutes, setInstitutes] = useState([]);
  const [users, setUsers] = useState([]);
  const [roles, setRoles] = useState([]);
  useEffect(() => {
    // Fetch Institutes
    setInstitutes([
      "Institute 1",
      "Institute 2",
      "Institute 3",
      "Institute 4",
    ]);
    // Fetch Users
    setUsers([
      "User 1",
      "User 2",
      "User 3",
      "User 4",
    ]);
    setRoles([
      "Admin",
      "Editor",
      "Viewer",
      "Manager",
    ]);
  }, []);
  const headers = ['NAME OF THE USER', 'SERVICE NUMBER', 'EMAIL ID', 'ASSIGN ROLE', 'ACTION'];
  const data = [
    { name: 'Bprd', color: '200002', category: 'bprdhead@cdac.in', price: 'bprddg' },
    { name: 'DK', color: '441905', category: 'adtrg.dc.2@bprd.nic.in', price: 'bprdadmin'},
    { name: 'Nitish', color: '000001', category: 'nkbanerjee@bprd.nic.in', price: 'bprdadmin'},
    { name: 'Bprd', color: '2121212', category: 'bprdadmin@cdac.in', price: 'bprdadmin' },
    { name: 'Nitish', color: '629103', category: 'banerjeecdts@rediffmail.com', price: 'bprddg'},
  ];
  return (
    <>
        <div className="h-full w-full">
          <div className="pr-3 bg-white  rounded mx-auto  w-full h-full">
            <div className="flex flex-col gap-3">
              <div className="flex flex-col basis-12/12  gap-3 border rounded-xl bg-gray-50">
             
                <h2 className="font-bold text-xl p-4">Assign role</h2>
               
              </div>
            <div className="flex gap-3">
             
              <div className="h-full w-full border rounded-xl basis-5/12 bg-gray-50">
              <div className="flex flex-col  h-[calc(100vh-224px)]">
            
             <form className=" p-5 ">
             
                
                <label className=" block mb-4">
                <span className="text-gray-700 font-bold">Select Institute *</span>
                <select
                  className="bg-white block w-full border border-gray-300 rounded-xl p-2 mt-2 focus:ring-2 focus:ring-blue-300 focus:outline-none"
                >
                  <option value="">-- Select Institute --</option>
                  {institutes.map((institute, index) => (
                    <option key={index} value={institute}>
                      {institute}
                    </option>
                  ))}
                </select>
              </label>
              <label className="block mb-4">
                <span className="text-gray-700 font-bold">Select User *</span>
                <select
                  className=" bg-white block w-full border border-gray-300 rounded-lg p-2 mt-2 focus:ring-2 focus:ring-blue-300 focus:outline-none"
                >
                  <option value="">-- Select User --</option>
                  {users.map((user, index) => (
                    <option key={index} value={user}>
                      {user}
                    </option>
                  ))}
                </select>
              </label>
              <label className="block mb-4">
                <span className="text-gray-700 font-bold">Select Role *</span>
                <select
                  className=" bg-white block w-full border border-gray-300 rounded-lg p-2 mt-2 focus:ring-2 focus:ring-blue-300 focus:outline-none"
                >
                  <option value="">-- Select Role --</option>
                  {roles.map((role, index) => (
                    <option key={index} value={role}>
                      {role}
                    </option>
                  ))}
                </select>
              </label>
            </form>
            
            <div className=" flex flex-col p-4 ">
              <button
                type="submit"
                className=" bg-blue-400 text-white  rounded-lg hover:bg-blue-600 transition-colors ">
                Assign Role
              </button>
              </div>
            </div>
          </div>
         
            <div className="min-h-full border rounded-xl basis-7/12 bg-gray-50 overflow-hidden">
               <div className=" overflow-y-auto">
                 <table className="w-full text-left bg-gray-50 rounded-xl p-5 ">
                   <thead>
                     {headers && (
                       <tr>
                         {headers.map((header, index) => (
                           <th
                             key={index}
                             className="px-3 py-4 text-sm font-semibold border-b bg-gray-100 text-black">
                             {header}
                           </th>
                         ))}
                       </tr>
                     )}
                   </thead>
                   <tbody>
                     {data.map((row, rowIndex) => (
                       <tr key={rowIndex} className="hover:bg-gray-100">
                         {Object.entries(row).map(([key, value], cellIndex) => (
                           <td
                             key={cellIndex}
                             className="px-5 py-5 text-sm border-b border-gray-200 text-black text-left">
                             {value}
                           </td>
                         ))}
                         <td className=" text-sm border-b border-gray-200 text-black p-3">
                           <button
                             className="bg-blue-400 text-white text-xs px-2 py-2 rounded hover:bg-blue-600 transition"
                             onClick={() =>
                               onEditclick(row) 
                               }>
                             Relieve<FontAwesomeIcon icon={faUserXmark}  className="pl-1" />
                           </button>
                         </td>
                       </tr>
                     ))}
                   </tbody>
                 </table>
                 </div>
               </div>
              
               
               </div>
               </div>
               </div>
             </div>
            

    </>
  );
}

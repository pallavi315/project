
import React from "react";
import BasicTable from "../../ui/Table/normaltable.jsx";

const Bprdadmin = () => {
  const headers = ['FIRST NAME', 'LAST NAME', 'MOBILE', 'SERVICE NO', 'CENTER'];
  const data = [
    { name: 'D K', color: 'Gaur', category: '9419059953', price: '941905', no: "BPRD HQ" },
    { name: 'Nitish', color: 'Banerjee', category: '9013932667', price: '0000001', no: "BPRD HQ" },
    { name: 'Bprd', color: 'Admin', category: '6161616161', price: '2121212', no: "BPRD HQ" },
  ];
  return (
    <>
          <div className="h-full w-full">
           <div className="pr-3 bg-white  rounded mx-auto  w-full h-full">
            <div className="flex flex-col gap-3 "> 
            <div className="flex flex-col basis-12/12 gap-3 border rounded-xl bg-gray-50">
              <h2 className="font-bold text-xl p-4">View BPR&D Admin Details</h2>
              </div>
              <div className="flex flex-col gap-3 h-[calc(100vh-222px)]">
            <div className="flex flex-col basis 12/12 gap-3 border rounded-xl h-full w-full bg-gray-50 overflow-hidden">
           <BasicTable headers={headers} data={data}/>
           </div>
           </div>
           </div>
           </div>
           </div>
      
    </>
  );
};
export default Bprdadmin;

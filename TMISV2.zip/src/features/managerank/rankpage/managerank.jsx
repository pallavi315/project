import React from "react";
import EditTable from "../../../ui/Table/edittable";
import { useNavigate } from "react-router-dom";
export function Managerank(){
    const headers = ['RANK NAME', 'ACTION'];
  const data = [
    { name: 'DGP'},
    { name: 'IG' },
    { name: 'DIG' },
    { name: 'ADG'},
    { name: 'SP' },
    { name: 'DSP' },
    { name: 'Inspector of Police'},
    { name: 'SI' },
    { name: 'ASI' },
    { name: 'Head Constable' },
    { name: 'Constable' },
    { name: 'ACP' },
    { name: 'Assistant Director' },
    { name: 'Assistant' },
    { name: 'PA or PS' },
    { name: 'UDC and LDC' },
    { name: 'Vice Principal' },
    { name: 'API' },
    { name: 'DCP' },
    { name: 'ASP' },
    { name: 'SSP' },
    { name: 'AddI CP' },
    { name: 'Joint CP' },
    { name: 'Inspector' },
    { name: 'AC' },
    { name: 'DC' },
    { name: 'two IC' },
    { name: 'Commandant' },
    { name: 'Senior Commandant' },
    { name: 'Team Commander' },
    { name: 'Squadron Commander' },
    { name: 'Group Commander' },
    { name: 'Prosecutor Officer' },
    { name: 'Judical Officer' },
    { name: 'Forest Officer' },
    { name: 'Proson Officer' },
    { name: 'Student' },
    { name: 'Public Prosecutor' },
    { name: 'Judge' },
    { name: 'NGO' },
    { name: 'Navy Officer' },
    { name: 'Air Force Officer' },
    { name: 'SI GD' },
    { name: 'Inspector GD' },
    { name: 'SI Tech' },
    { name: 'Inspector Tech' },
    { name: 'Warrant Officer' },
    { name: 'Junior Warrant Officer' },
    { name: 'Sergeant' },
    { name: 'APP' },
    { name: 'Jailor' },
    { name: 'Supdt of jails' },
    { name: 'Naik' },
    { name: 'Subedar' },
    { name: 'Major' },
    { name: 'Captain' },
    { name: 'Lt colonel' },
    { name: 'SI Executive' },
    { name: 'Inspector EXecutive' },
    { name: 'Forensic Officer' },
    { name: 'Judges' },
    { name: 'Director' },
    { name: 'IAS Officer' },
    { name: 'SDM' },
    { name: 'Tehsildar' },
    { name: 'Financial Officer' },
    { name: 'Assistant Financial Officer' },
    { name: 'Legal Officer' },
    { name: 'Assistant legal Officer' },
  ];
  const navigate = useNavigate();

  const handleAddRank = () => {
    navigate("/private/features/manage-rank/add-rank");
  }
  const handleEditrank = (rowData) => {
    navigate("/private/features/manage-rank/edit-rank", {
      state: { rowData }, // Pass the rowData in the state
    });
  };
    return(
        <>
      <div className="h-full w-full">
           <div className="pr-3 bg-white  rounded mx-auto  w-full h-full">
            <div className="flex flex-col gap-3 "> 
            <div className="flex flex-col basis-12/12 gap-3 border rounded-xl bg-gray-50 p-3">
              <div className="flex justify-between">
                <div className="flex item-center">
                  <h2 className="font-bold text-xl item-center p-3">View Ranks</h2>
                  </div>
                  <div className="flex">
                  <button
          className="bg-blue-400 text-white text-center rounded-lg"
          onClick={handleAddRank}>
          Add Rank
        </button>
        </div>
          </div>
              </div>
              
             <div className="flex flex-col gap-3 h-[calc(100vh-238px)]">
              <div className="flex flex-col border rounded-xl h-full bg-gray-50 overflow-hidden">
                <div className="overflow-y-auto h-full">
                  <EditTable headers={headers} data={data} onEditclick={handleEditrank} />
                </div>
              </div>
            </div>
           </div>
           </div>
           </div>
        </>
    )
}
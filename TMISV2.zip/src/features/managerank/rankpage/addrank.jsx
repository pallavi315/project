import React from "react";

export function AddRank() {
  return (
    <>
    <div className="h-full w-full">
    <div className="pr-3 bg-white  rounded mx-auto  w-full h-full">
            <div className="flex flex-col gap-3 "> 
            <div className="flex flex-col basis-12/12 gap-3 border rounded-xl bg-gray-50">
      <h1 className="text-xl font-bold p-3">Add Rank</h1>
      </div>
      <div className="border rounded-lg h-full bg-gray-50">
      <div className="gap-3 h-[calc(100vh-232px)]">
      <form className="p-4">
        <label className="block mb-4">
          <span className="text-gray-700 font-bold">Rank Name *</span>
          <input
            type="text"
            placeholder="Enter Rank Name"
            className="w-full block border border-gray-300 rounded-lg p-2 mt-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
          />
        </label>
        <button
          type="submit"
          className="bg-blue-500 text-white text-center py-2 rounded-xl hover:bg-blue-600 transition-colors"
          onClick={() => navigate("/private/features/manage-rank")}>
          Submit
        </button>
      </form>
      </div>
      </div>
    </div>
    </div>
    </div>
    </>
  );
}

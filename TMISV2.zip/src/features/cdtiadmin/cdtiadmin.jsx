import React from "react";
import BasicTable from "../../ui/Table/normaltable";

export default function Cdtiadmin(){
    const headers = ['FIRST NAME', 'LAST NAME', 'MOBILE', 'SERVICE NO', 'CENTER'];
  const data = [
    { name: 'Bheema', color: 'Naik', category: '8333974216', price: '833397', no: "Central Detective Training Institute Hyderabad" },
    { name: 'Ms Rachna', color: 'Rachna', category: '8650701199', price: '324345', no: "Central Detective Training Institute Ghaziabad" },
    { name: 'Subhajit', color: 'Chaudhuri', category: '9433122741', price: '943312', no: "Central Detective Training Institute Kolkata" },
    { name: 'Karthik', color: 'Srinivas', category: '9441320512', price: '944312', no: "CDAC Hyderabad" },
    { name: 'Sanjay', color: 'Verma', category: '9971597007', price: '323423', no: "Central Detective Training Institute Ghaziabad" },
  ];
    return(
        <>
          <div className="h-full w-full">
  <div className="pr-3 bg-white rounded mx-auto w-full h-full">
    <div className="flex flex-col gap-3">
     
       <div className="flex flex-col basis-12/12 border rounded-xl bg-gray-50">
        <h2 className="font-bold text-xl p-4">View CDTI Admin Details</h2>
      </div>
      <div className="flex flex-col gap-3 h-[calc(100vh-222px)]">
        
        <div className="flex flex-col h-full basis-12/12 border rounded-xl w-full overflow-hidden bg-gray-50">
          <BasicTable headers={headers} data={data} />
        </div>
        
      </div>
     
    </div>
  </div>
</div>
        </>
    )
}

import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

export function Adduser() {
  const navigate = useNavigate();
  const [organizations, setOrganizations] = useState([
    { name: "Organization 1" },
    { name: "Organization 2" },
    { name: "Organization 3" },
  ]);
  const [ranks, setRanks] = useState([
    { name: "Rank 1" },
    { name: "Rank 2" },
    { name: "Rank 3" },
  ]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Fetch organizations from the API (if needed in the future)
  // useEffect(() => {
  //   const fetchOrganizations = async () => {
  //     try {
  //       const response = await fetch("/api/organizations"); // Replace with your API endpoint
  //       if (!response.ok) {
  //         throw new Error("Failed to fetch organizations");
  //       }
  //       const data = await response.json();
  //       setOrganizations(data);
  //     } catch (err) {
  //       setError(err.message);
  //     } finally {
  //       setLoading(false);
  //     }
  //   };

  //   const fetchRanks = async () => {
  //     try {
  //       const response = await fetch("/api/manage-rank"); // Replace with your API endpoint
  //       if (!response.ok) {
  //         throw new Error("Failed to fetch ranks");
  //       }
  //       const data = await response.json();
  //       setRanks(data);
  //     } catch (err) {
  //       setError(err.message);
  //     }
  //   };

  //   fetchOrganizations();
  //   fetchRanks();
  // }, []);

  return (
    <>
      <div className="h-full w-full">
        {/* <div className="p-6 bg-white shadow-md rounded-lg mx-auto m-5"> */}
        <div className="pr-3 bg-white  rounded mx-auto  w-full h-full">
            <div className="flex flex-col gap-3 "> 
            <div className="flex flex-col basis-12/12 gap-3 border rounded-xl bg-gray-50">
          <h1 className="text-2xl font-bold p-4">User Registration</h1>
          </div>
          {/* {loading ? (
              <p>Loading organizations...</p>
            ) : error ? (
              <p className="text-red-500">Error: {error}</p>
            ) : ( */}
            <div className="border rounded-xl bg-gray-50">
          <form className="p-4">
            <div className="fle flex-col">
            <label className="block mb-4">
              <span className="text-gray-700 font-bold">First Name *</span>
              <input
                type="text"
                className="block w-full border border-gray-300 rounded-lg p-2 mt-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </label>
            <label className="block mb-4">
              <span className="text-gray-700 font-bold">Last Name *</span>
              <input
                type="text"
                className="block w-full border border-gray-300 rounded-lg p-2 mt-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </label>
            <label className="block mb-4">
              <span className="text-gray-700 font-bold">Email *</span>
              <input
                type="text"
                className="block w-full border border-gray-300 rounded-lg p-2 mt-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </label>
            <label className="block mb-4">
              <span className="text-gray-700 font-bold">Organization *</span>
              <select
                className=" bg-white block w-full border border-gray-300 rounded-lg p-2 mt-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
              >
                <option value="">
                  -- Select Organization --
                </option>
                {organizations.map((org, index) => (
                  <option key={index} value={org.name}>
                    {org.name}
                  </option>
                ))}
              </select>
            </label>
            <label className="block mb-4">
              <span className="text-gray-700 font-bold">Mobile No*</span>
              <input
                type="text"
                placeholder="0"
                className="block w-full border border-gray-300 rounded-lg p-2 mt-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </label>
            <label className="block mb-4">
              <span className="text-gray-700 font-bold">Service No *</span>
              <input
                type="text"
                className="block w-full border border-gray-300 rounded-lg p-2 mt-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </label>
            <label className="block mb-4">
              <span className="text-gray-700 font-bold">Rank Name *</span>
              <select
                className="bg-white block w-full border border-gray-300 rounded-lg p-2 mt-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
              >
                <option value="" >
                  -- Select Rank --
                </option>
                {ranks.map((rank, index) => (
                  <option key={index} value={rank.name}>
                    {rank.name}
                  </option>
                ))}
              </select>
            </label>
            <button
              type="submit"
              className="bg-blue-500 text-white text-center py-2 rounded-lg hover:bg-blue-600 transition-colors"
              onClick={() => navigate("/private/features/manage-user")}
            >
              Save
            </button>
            </div>
          </form>
          {/* )} */}
          </div>
        </div>
        </div>
      </div>
    </>
  );
}

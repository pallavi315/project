import React from "react";
import Table from "../../../ui/Table/table";
import { useNavigate } from "react-router-dom";
export function Manageuser(){
    const headers = ['FIRST NAME', 'LAST NAME', 'EMAIL','MOBILE', 'SERVICE NO',];
  const data = [
    { name: 'Bprd', color: 'Head', category: 'bprdhead@cdac.in', price: '9454545454', no: "200002" },
    { name: 'Prabhu', color: 'Singh', category: 'cdts.bprdjaipur@gmail.com', price: '7748039281', no: "987654" },
    { name: 'Vamshi', color: 'Krishna', category: 'muday@cdac.in', price: '6789654321', no: "678911" },
    { name: 'Abhay', color: 'Kumar', category: 'abhaymallickkol@govcontractor.in', price: '9493162097', no: "949316" },
    { name: 'DK', color: 'Gaur', category: 'adtrg.dc-2@bprd.nic.in', price: '7008457012', no: "700845" },
    { name: 'Bheema', color: 'Naik', category: 'vadithe@bprd.nic.in', price: '8333974216', no: "833397" },
    { name: 'Virendra', color: 'Kumar', category: 'virendrgh@bprd.nic.in', price: '9968892424', no: "996889" },
    { name: 'Nitish', color: 'Banerjee', category: 'nkbanerjee@bprd.nic.in', price: '9013932667', no: "000001" },
    { name: 'Ms Rachna', color: 'Rachna', category: 'rachnagh@bprd.nic.in', price: '8650701199', no: "324345" },
    { name: 'CDAC', color: 'CDTI Admins', category: 'cdti@cdac.in', price: '9222222222', no: "200000" },
    { name: 'Nitish', color: 'Banerjee', category: 'banerjeecdts@rediffmail.com', price: '6291038155', no: "629103" },
    { name: 'Harsh', color: 'Kumar', category: 'harshk.1995@bprd.nic.in', price: '8409944129', no: "840994" },
    { name: 'Director', color: 'CDAC Hyderabad', category: 'director@cdac.in', price: '9444444444', no: "200001" },
    { name: 'Director', color: 'Jaipur', category: 'director.cdti.rj@gov.in', price: '8112216377', no: "811221" },
    { name: 'Subhajit', color: 'Chaudhuri', category: 'cdts.kol.bprd@nic.in', price: '9433122741', no: "943312" },
    { name: 'Karthik', color: 'Srinivas', category: 'ksrinivas@cdac.in', price: '9441320511', no: "9441321" },
    { name: 'Sanjay', color: 'Verma', category: 'sanjayverma@bprd.nic.in', price: '9971597007', no: "323423" },
    { name: 'Daljit', color: 'Singh', category: 'cdtstrg@chd.nic.in', price: '7006466936', no: "9216501966" },
    { name: 'Rani Bindu Sachdeva IPS', color: 'Director CDTI Chandigarh', category: 'ranibinduchg@bprd.nic.in', price: '9418453439', no: "945917" },
    { name: 'bprd', color: 'test', category: 'firdhouz@bprd.nic.in', price: '9475592375', no: "011199638" },
    { name: 'Bprd', color: 'Admin', category: 'bprdadmin@cdac.in', price: '6161616161', no: "21212121" },
    { name: 'Anusuya', color: 'Baral', category: 'anusuya.baral@bprd.nic.in', price: '9000000000', no: "900000" },
    { name: 'Amit', color: 'Atut', category: 'adindoor-capt@bprd.nic.in', price: '9630089521', no: "963008" },
    { name: 'Dr Sachin', color: 'Gupta', category: 'sachon-gupta@bprd.nic.in', price: '9718406931', no: "015202" },
    { name: 'Ramu', color: 'parupalli', category: 'ramup@cdac.in', price: '9876543211', no: "917766" },
    { name: 'Shaffali', color: 'Takalkar', category: 'ictech-capt@bprd.nic.in', price: '9926434396', no: "992643" }
  ];
  const navigate = useNavigate();
  const handleAdduser = () => {
    navigate("/private/features/manage-user/add-user");
  }
    return(
        <>
      <div className="h-full w-full">
           <div className="pr-3 bg-white  rounded mx-auto  w-full h-full">
            <div className="flex flex-col gap-3 "> 
            
            <div className="flex flex-col basis-12/12 gap-3 border rounded-xl bg-gray-50">
            <div className="flex justify-between P-4">
                <div className="flex item-center p-3">
                  <h2 className="font-bold text-xl p-3 item-center">View Users</h2>
                  </div>
              <div className="flex p-3">
                  <button
          className="bg-blue-400 text-white text-center rounded-lg"
          onClick={handleAdduser}>
          Add User
        </button>
        </div>
            </div>  
            </div>
            <div className="flex flex-col gap-3 h-[calc(100vh-238px)]">
            <div className="flex flex-col basis 12/12  border rounded-xl h-full bg-gray-50 overflow-hidden">
            
           <Table headers={headers} data={data} />
           </div>
          </div>
           </div>
           </div>
           </div>
        </>
    )
}
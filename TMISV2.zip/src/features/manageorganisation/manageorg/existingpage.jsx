import React from "react";
import EditTable from "../../../ui/Table/edittable";
import { useNavigate } from "react-router-dom";
export default function Manageorg() {
  const headers = ['ORGANIZATION', 'ORGANIZATION ADDRESS', 'ACTION'];
  const data = [
    { name: 'BPRD HQ', address: 'New Delhi' },
    { name: 'Central Detective Training Institute Hyderabad', address: 'Hyderabad' },
    { name: 'Central Detective Training Institute Ghaziabad', address: 'Ghaziabad' },
    { name: 'Central Detective Training Institute Kolkata', address: 'Kolkata' },
    { name: 'Central Detective Training Institute Jaipur', address: 'Jaipur' },
    { name: 'Central Detective Training Institute Chandigarh', address: 'Chandigarh' },
    { name: 'Central Detective Training Institute Bhopal', address: 'Bhopal' },
    { name: 'Central Detective Training Institute Shamshabad', address: 'Shamshabad' }
  ];
  const navigate = useNavigate();
  const handleAddorg = () => {
    navigate("/private/features/manage-organization/add-organization");
  }
  const handleEditorg = (rowData) => {
    navigate("/private/features/manage-organization/edit-organization", {
      state: { rowData }, // Pass the rowData in the state
    });
  };
  return (
      <div className="h-full w-full">
     <div className="pr-3 rounded mx-auto w-full h-full">
    <div className="flex flex-col gap-3">
      <div className="flex flex-col basis-12/12 gap-3 border rounded-xl bg-gray-50">
      <div className="flex justify-between p-3 ">
        <div className="flex item-center">
        <h2 className="font-bold text-xl text-center p-3">View Organization</h2>
      </div>
        <div className="flex item-center">
          <button
            className="bg-blue-400 text-white text-center rounded-lg "
            onClick={handleAddorg}>
            Add Organization
          </button>
        </div>
        </div>
      </div>
      <div className="flex flex-col gap-3 h-[calc(100vh-238px)]">
      <div className="flex flex-col gap-3 h-full basis-12/12 bg-gray-50 border rounded-xl overflow-hidden">
          <EditTable headers={headers} data={data} onEditclick={handleEditorg} />
          </div>
          </div>
          </div>
        </div>
      </div>
  );
}

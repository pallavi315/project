
import React from "react";
import { useLocation, useNavigate } from "react-router-dom";
import BprdAdminPage from "../../../ui/header/header";
import { Footer } from "../../../ui/footer/footer";
        
export default function Editorganization () {
          const location = useLocation();
          const navigate = useNavigate();
        
          // Retrieve the row data passed from the table
          const rowData = location.state?.rowData || {
            name: "",
            address: "",
            code: "",
          };
        
          const [formState, setFormState] = React.useState(rowData);
        
          const handleChange = (e) => {
            const { name, value } = e.target;
            setFormState({ ...formState, [name]: value });
          };
        
          const handleSubmit = (e) => {
            e.preventDefault();
            console.log("Updated Data:", formState);
        
            // Redirect to the table after saving
            navigate("/private/features/manage-organization");
          };
        
          return (
            <>
            
            <div className="h-full w-full">
           <div className="pr-3 bg-white  rounded mx-auto  w-full h-full">
            <div className="flex flex-col gap-3 "> 
            <div className="flex flex-col basis-12/12 gap-3 border rounded-xl bg-gray-50">
              <h2 className="font-bold text-xl p-4">Update Organization</h2>
              </div>
            <div className="flex flex-col basis 12/12 gap-3 border rounded-xl h-full bg-gray-50 ">
            <div className="gap-3 h-[calc(100vh-230px)]">
              <form onSubmit={handleSubmit} className="p-4">
          
                <label className="block mb-4">
                  <span className="text-gray-700 font-bold">Organization Name *</span>
                  <input
                    type="text"
                    name="name"
                    value={formState.name}
                    onChange={handleChange}
                    placeholder="Enter Organization Name"
                    className="block w-full border border-gray-300 rounded-lg p-2 mt-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"/>
                </label>
                <label className="block mb-4">
                  <span className="text-gray-700 font-bold">Organization Address *</span>
                  <input
                    type="text"
                    name="address"
                    value={formState.address}
                    onChange={handleChange}
                    placeholder="Enter Organization Address"
                    className="block w-full border border-gray-300 rounded-lg p-2 mt-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                </label>
                <label className="block mb-4">
                  <span className="text-gray-700 font-bold">Organization Code *</span>
                  <input
                    type="text"
                    name="code"
                    value={formState.code}
                    onChange={handleChange}
                    placeholder="Enter Organization Code"
                    className="block w-full border border-gray-300 rounded-lg p-2 mt-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                </label>
                <button
                  type="submit"
                  className="bg-blue-500 text-white text-center py-2 rounded-lg hover:bg-blue-600 transition-colors"
                  onClick={() => navigate("/private/features/manage-organization")}>
                  Submit
                </button>
                <button
                  type="button"
                  className="bg-gray-500 text-white text-center py-2 rounded-lg ml-4 hover:bg-gray-600 transition-colors"
                  onClick={() => navigate("/private/features/manage-organization")}>
                  Cancel
                </button>
              </form>
              </div>
              </div>
              </div>
            </div>
            </div>
            </>
          );
        };
        

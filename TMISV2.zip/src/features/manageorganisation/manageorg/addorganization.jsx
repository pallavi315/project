import React from "react";
import { Form } from "../../../ui/forms/forms";

export function Addorganization(){
    return(
        <>
        <div className="h-full w-full">
           <div className="pr-3 bg-white  rounded mx-auto  w-full h-full">
            <div className="flex flex-col gap-3 "> 
            <div className="flex flex-col basis-12/12 gap-3 border rounded-xl bg-gray-50">
              <h2 className="font-bold text-xl p-4">Add Organization</h2>
              </div>
            <div className="flex flex-col basis 12/12 gap-3 border rounded-lg h-full bg-gray-50">
            <div className="gap-3 h-[calc(100vh-230px)]">
           <Form/>
           </div>
           </div>
           </div>
           </div>
           </div>
        </>
    )
}

import React from "react";
export function Dashboard(){
    return(
        <h1>Dashboard</h1>
    )

}